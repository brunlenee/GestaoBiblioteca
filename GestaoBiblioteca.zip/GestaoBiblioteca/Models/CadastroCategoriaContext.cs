﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class CadastroCategoriaContext : DbContext
    {
     
    
        public CadastroCategoriaContext() : base("name=CadastroCategoriaContext")
        {
        }

        public System.Data.Entity.DbSet<GestaoBiblioteca.Models.CadastroCategoria> CadastroCategorias { get; set; }
    }
}
