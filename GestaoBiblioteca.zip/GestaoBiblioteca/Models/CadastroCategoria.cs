﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class CadastroCategoria
    {
        public int Id { get; set; }

        [DisplayName("Nome da Categoria")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 20 caracteres")]
        public string  Nome { get; set; }

        [DisplayName("Situação")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        public bool Situacao { get; set; }


    }
}