﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class DadosPessoa
    {
        public int Id { get; set; }
        public int CPF { get; set; }
        public int RG { get; set; }

    }
}