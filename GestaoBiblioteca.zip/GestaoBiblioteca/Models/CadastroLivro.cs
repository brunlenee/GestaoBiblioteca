﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class CadastroLivro
    {
        public int Id { get; set; }

        public int ISBN { get; set; }

        [DisplayName("Titulo do Livro")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 20 caracteres")]
        public string Titulo { get; set; }

        public AutorLivro Autor { get; set; }

        [DisplayName("Editora do LIvro")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(13, ErrorMessage = "No maximo 13 caracteres")]
        public string Editora { get; set; }

        [DisplayName("Edição")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 10 caracteres")]
        public string Edicao { get; set; }

        [DisplayName("Ano")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(8, ErrorMessage = "No maximo 8 caracteres")]
        public int Ano { get; set; }

        public CategoriaLivro Categoria { get; set; }

        [DisplayName("Situação")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        public bool Situacao { get; set; }
       

    }
}