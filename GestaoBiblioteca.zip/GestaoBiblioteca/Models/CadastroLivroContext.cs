﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class CadastroLivroContext : DbContext
    {
  
    
        public CadastroLivroContext() : base("name=CadastroLivroContext")
        {
        }

        public System.Data.Entity.DbSet<GestaoBiblioteca.Models.CadastroLivro> CadastroLivroes { get; set; }
    }
}
