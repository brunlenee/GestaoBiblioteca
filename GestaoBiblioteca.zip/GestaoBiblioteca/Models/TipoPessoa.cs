﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class TipoPessoa
    {
        public int Id { get; set; }

        /* lista de autor professor aluno e outros */ 
    }
}