﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class CadastroPessoa
    {
        public int Id { get; set; }

        [DisplayName("Nome da Pessoa")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 20 caracteres")]
        public string Nome { get; set; }

        [DisplayName("Seus Dados Pessoais")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 20 caracteres")]
        public DadosPessoa DadosPessoais { get; set; }

        [DisplayName("Seu Contato")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        [StringLength(20, ErrorMessage = "No maximo 20 caracteres")]
        public ContatosPessoa Contato { get; set; }
        

        public TipoPessoa Tipo { get; set; }

        [DisplayName("Situção")]
        [Required(ErrorMessage = "Campo Obrigatorio")]
        public bool Situacao { get; set; }
    }
}