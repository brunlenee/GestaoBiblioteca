﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class GestaoBibliotecaContext : DbContext
    {
      
    
        public GestaoBibliotecaContext() : base("name=GestaoBibliotecaContext")
        {
        }

        public System.Data.Entity.DbSet<GestaoBiblioteca.Models.CadastroPessoa> CadastroPessoas { get; set; }
    }
}
