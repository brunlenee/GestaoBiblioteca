﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestaoBiblioteca.Models
{
    public class ContatosPessoa
    {
        public int Id { get; set; }
        public TelefonePessoa Telefone { get; set; }
        public EmailPessoa Email { get; set; }


    }
}