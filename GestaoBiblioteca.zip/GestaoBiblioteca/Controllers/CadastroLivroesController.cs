﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GestaoBiblioteca.Models;

namespace GestaoBiblioteca.Controllers
{
    public class CadastroLivroesController : Controller
    {
        private CadastroLivroContext db = new CadastroLivroContext();

        // GET: CadastroLivroes
        public ActionResult Index()
        {
            return View(db.CadastroLivroes.ToList());
        }

        // GET: CadastroLivroes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroLivro cadastroLivro = db.CadastroLivroes.Find(id);
            if (cadastroLivro == null)
            {
                return HttpNotFound();
            }
            return View(cadastroLivro);
        }

        // GET: CadastroLivroes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CadastroLivroes/Create
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ISBN,Titulo,Editora,Edicao,Ano,Situacao")] CadastroLivro cadastroLivro)
        {
            if (ModelState.IsValid)
            {
                db.CadastroLivroes.Add(cadastroLivro);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(cadastroLivro);
        }

        // GET: CadastroLivroes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroLivro cadastroLivro = db.CadastroLivroes.Find(id);
            if (cadastroLivro == null)
            {
                return HttpNotFound();
            }
            return View(cadastroLivro);
        }

        // POST: CadastroLivroes/Edit/5
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ISBN,Titulo,Editora,Edicao,Ano,Situacao")] CadastroLivro cadastroLivro)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cadastroLivro).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cadastroLivro);
        }

        // GET: CadastroLivroes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroLivro cadastroLivro = db.CadastroLivroes.Find(id);
            if (cadastroLivro == null)
            {
                return HttpNotFound();
            }
            return View(cadastroLivro);
        }

        // POST: CadastroLivroes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CadastroLivro cadastroLivro = db.CadastroLivroes.Find(id);
            db.CadastroLivroes.Remove(cadastroLivro);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
