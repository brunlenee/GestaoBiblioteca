﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GestaoBiblioteca.Models;

namespace GestaoBiblioteca.Controllers
{
    public class CadastroPessoasController : Controller
    {
        private GestaoBibliotecaContext db = new GestaoBibliotecaContext();

        // GET: CadastroPessoas
        public ActionResult Index()
        {
            return View(db.CadastroPessoas.ToList());
        }

        // GET: CadastroPessoas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroPessoa cadastroPessoa = db.CadastroPessoas.Find(id);
            if (cadastroPessoa == null)
            {
                return HttpNotFound();
            }
            return View(cadastroPessoa);
        }

        // GET: CadastroPessoas/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CadastroPessoas/Create
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Nome,Situacao")] CadastroPessoa cadastroPessoa)
        {
            if (ModelState.IsValid)
            {
                db.CadastroPessoas.Add(cadastroPessoa);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(cadastroPessoa);
        }

        // GET: CadastroPessoas/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroPessoa cadastroPessoa = db.CadastroPessoas.Find(id);
            if (cadastroPessoa == null)
            {
                return HttpNotFound();
            }
            return View(cadastroPessoa);
        }

        // POST: CadastroPessoas/Edit/5
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Nome,Situacao")] CadastroPessoa cadastroPessoa)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cadastroPessoa).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cadastroPessoa);
        }

        // GET: CadastroPessoas/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroPessoa cadastroPessoa = db.CadastroPessoas.Find(id);
            if (cadastroPessoa == null)
            {
                return HttpNotFound();
            }
            return View(cadastroPessoa);
        }

        // POST: CadastroPessoas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CadastroPessoa cadastroPessoa = db.CadastroPessoas.Find(id);
            db.CadastroPessoas.Remove(cadastroPessoa);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
