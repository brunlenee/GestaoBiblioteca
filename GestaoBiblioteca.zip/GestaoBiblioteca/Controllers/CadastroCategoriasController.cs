﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GestaoBiblioteca.Models;

namespace GestaoBiblioteca.Controllers
{
    public class CadastroCategoriasController : Controller
    {
        private CadastroCategoriaContext db = new CadastroCategoriaContext();

        // GET: CadastroCategorias
        public ActionResult Index()
        {
            return View(db.CadastroCategorias.ToList());
        }

        // GET: CadastroCategorias/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroCategoria cadastroCategoria = db.CadastroCategorias.Find(id);
            if (cadastroCategoria == null)
            {
                return HttpNotFound();
            }
            return View(cadastroCategoria);
        }

        // GET: CadastroCategorias/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CadastroCategorias/Create
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Nome,Situacao")] CadastroCategoria cadastroCategoria)
        {
            if (ModelState.IsValid)
            {
                db.CadastroCategorias.Add(cadastroCategoria);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(cadastroCategoria);
        }

        // GET: CadastroCategorias/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroCategoria cadastroCategoria = db.CadastroCategorias.Find(id);
            if (cadastroCategoria == null)
            {
                return HttpNotFound();
            }
            return View(cadastroCategoria);
        }

        // POST: CadastroCategorias/Edit/5
        // Para se proteger de mais ataques, ative as propriedades específicas a que você quer se conectar. Para 
        // obter mais detalhes, consulte https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Nome,Situacao")] CadastroCategoria cadastroCategoria)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cadastroCategoria).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cadastroCategoria);
        }

        // GET: CadastroCategorias/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CadastroCategoria cadastroCategoria = db.CadastroCategorias.Find(id);
            if (cadastroCategoria == null)
            {
                return HttpNotFound();
            }
            return View(cadastroCategoria);
        }

        // POST: CadastroCategorias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CadastroCategoria cadastroCategoria = db.CadastroCategorias.Find(id);
            db.CadastroCategorias.Remove(cadastroCategoria);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
